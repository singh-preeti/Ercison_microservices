package com.contact.service;

import com.contact.entity.Contact;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactServiceImpl implements ContactService {

    //fake list of contacts

    List<Contact> list = List.of(
            new Contact(1L, "Preety@gmail.com", "678889", 101L),
            new Contact(2L, "Shreya@gmail.com", "5678889", 102L)
           
    );


    @Override
    public List<Contact> getContactsOfUser(Long id) {
        return list.stream().filter(contact -> contact.getCid()
        		.equals(id))
        		.collect(Collectors.toList());
    }
}
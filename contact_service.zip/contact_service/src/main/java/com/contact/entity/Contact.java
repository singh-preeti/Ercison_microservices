package com.contact.entity;

public class Contact {
	private Long contact_id;
	private String email;
	private String mobile_no;
	
	private Long cid;

	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Contact(Long contact_id, String email, String mobile_no, Long cid) {
		super();
		this.contact_id = contact_id;
		this.email = email;
		this.mobile_no = mobile_no;
		this.cid = cid;
	}

	public Long getContact_id() {
		return contact_id;
	}

	public void setContact_id(Long contact_id) {
		this.contact_id = contact_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public Long getCid() {
		return cid;
	}

	public void setCid(Long cid) {
		this.cid = cid;
	}
	
	

}

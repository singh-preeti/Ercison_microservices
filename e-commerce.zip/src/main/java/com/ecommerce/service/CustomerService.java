package com.ecommerce.service;

import com.ecommerce.model.Customer;

public interface CustomerService {

	public Customer getCustomer(Long id);

}

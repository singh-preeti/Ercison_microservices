package com.ecommerce.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecommerce.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	//fake list of customer
	List<Customer> list = List.of(
			new Customer(101L,"Preeti",34,"IT"),
			new Customer(102L,"Shreya",20,"CS"));

	@Override
	public Customer getCustomer(Long id) {
		return this.list.stream()
				.filter(user -> 
				user.getCid()
				.equals(id))
				.findAny().orElse(null);
	}


}

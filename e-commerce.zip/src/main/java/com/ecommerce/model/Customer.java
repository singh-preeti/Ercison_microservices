package com.ecommerce.model;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	private Long cid;
	private String name;
	private int age;
	private String department;
	
	List<Contact> contact = new ArrayList<>();
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Customer(Long cid, String name, int age, String department, List<Contact> contact) {
		super();
		this.cid = cid;
		this.name = name;
		this.age = age;
		this.department = department;
		this.contact = contact;
	}

	public Customer(Long cid, String name, int age, String department) {
		super();
		this.cid = cid;
		this.name = name;
		this.age = age;
		this.department = department;
	}
	
	public List<Contact> getContact() {
		return contact;
	}

	public void setContact(List<Contact> contact) {
		this.contact = contact;
	}

	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	}

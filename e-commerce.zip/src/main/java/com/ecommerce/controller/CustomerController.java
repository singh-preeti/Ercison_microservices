package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.model.Contact;
import com.ecommerce.model.Customer;
import com.ecommerce.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private RestTemplate restTemplate;
	@GetMapping("/{id}")
	public Customer getCustomerbyId(@PathVariable Long id) {
		//return this.customerService.getCustomer(id);
		Customer customer= this.customerService.getCustomer(id);
		List<Contact> contacts = this.restTemplate.getForObject("localhost:9002/contact/customer/"+customer.getCid(), List.class);
		
		customer.setContact(contacts);
		
		return customer;
	 
	}

}
